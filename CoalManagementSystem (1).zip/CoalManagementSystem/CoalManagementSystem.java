// Base Class
class Company {
    protected String name;
    protected String location;

    public Company(String name, String location) {
        this.name = name;
        this.location = location;
    }

    public void displayInfo() {
        System.out.println("Company: " + name);
        System.out.println("Location: " + location);
    }
}

// Inheritance
class CoalMine extends Company {
    private Coal coal; // Composition
    private Employee[] employees; // Aggregation

    public CoalMine(String name, String location, Coal coal, Employee[] employees) {
        super(name, location);
        this.coal = coal;
        this.employees = employees;
    }

    public void showMineDetails() {
        displayInfo();
        coal.displayCoalInfo();
        System.out.println("Employees:");
        for (Employee e : employees) {
            System.out.println("- " + e.getName());
        }
    }
}

// Composition class
class Coal {
    private String type;
    private double quantity; // in tons

    public Coal(String type, double quantity) {
        this.type = type;
        this.quantity = quantity;
    }

    public void displayCoalInfo() {
        System.out.println("Coal Type: " + type);
        System.out.println("Quantity: " + quantity + " tons");
    }
}

// Aggregation class
class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

// Threading class
class CoalTransportThread extends Thread {
    private String transportName;

    public CoalTransportThread(String transportName) {
        this.transportName = transportName;
    }

    public void run() {
        System.out.println(transportName + " started transporting coal...");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(transportName + " interrupted.");
        }
        System.out.println(transportName + " finished transporting.");
    }
}

// Main class to test
public class CoalManagementSystem {
    public static void main(String[] args) {
        Coal coal = new Coal("Anthracite", 500);
        Employee[] employees = {
            new Employee("Alice"),
            new Employee("Bob"),
            new Employee("Charlie")
        };

        CoalMine mine = new CoalMine("BlackRock Mines", "Jharkhand", coal, employees);
        mine.showMineDetails();

        // Start transport threads
        CoalTransportThread t1 = new CoalTransportThread("Truck A");
        CoalTransportThread t2 = new CoalTransportThread("Truck B");

        t1.start();
        t2.start();
    }
}
